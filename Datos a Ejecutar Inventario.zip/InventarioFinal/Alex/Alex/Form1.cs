﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Alex
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Categoria formcategoria = new Categoria();  // Crea una nueva instancia del formulario GestionCategorias
            formcategoria.Show();  // Muestra el formulario sin cerrar el formulario principal
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Proveedor formproveedore = new Proveedor();  // Crea una nueva instancia del formulario GestionarProveedor
            formproveedore.Show();  // Muestra el formulario sin cerrar el formulario principal
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Productos formproducto = new Productos();  // Crea una nueva instancia del formulario GestionarProducto
            formproducto.Show();  // Muestra el formulario sin cerrar el formulario principal
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Reporte formreporte = new Reporte();  // Crea una nueva instancia del formulario GestionarReporte
            formreporte.Show();  // Muestra el formulario sin cerrar el formulario principal
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Close();  // Cierra el formulario principal

        }
    }
}
